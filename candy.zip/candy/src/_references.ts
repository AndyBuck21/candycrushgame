﻿/*-------GLOBAL-------*/
/// <reference path='../typings/tsd.d.ts' />


