/// <reference path='../_references.ts' />

module GameApp.Models {
	'use strict';
    
	 
	 export class Swap{
		 
		 cookieA: Cookie;
		 cookieB: Cookie;
		 
	 }
}