/// <reference path='../../../../../typings/mocha/mocha.d.ts' />
/// <reference path='../../../../../typings/chai/chai.d.ts' />
/// <reference path='../_references.ts' />